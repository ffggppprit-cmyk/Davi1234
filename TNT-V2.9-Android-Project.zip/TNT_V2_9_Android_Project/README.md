# TNT V2.9 — Protótipo Android

Este ZIP contém o código-fonte de um aplicativo demonstrativo com botões, interruptores e controle visual de FOV. Não é um APK pronto e não inclui aimbot/ESP funcional para Free Fire.

## Compilar
1. Extraia o ZIP.
2. Abra a pasta `TNT_V2_9_Android_Project` no Android Studio.
3. Aguarde a sincronização do Gradle e instale Android SDK Platform 35 se for solicitado.
4. Escolha **Build > Build APK(s)**.
5. O APK de debug costuma aparecer em `app/build/outputs/apk/debug/app-debug.apk`.

No celular, compilar depende de um ambiente Android/Gradle compatível. O ZIP é código-fonte, não APK pré-compilado.
