package com.example.tntv29;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    int BG=Color.rgb(8,10,22), PANEL=Color.rgb(17,20,39), PURPLE=Color.rgb(154,40,255), CYAN=Color.rgb(0,220,255);
    TextView status; int fov=120;
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    GradientDrawable shape(int c,int s){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(16));d.setStroke(dp(1),s);return d;}
    TextView txt(String s,int z,int c,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(b)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    void space(LinearLayout l,int h){View v=new View(this);l.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
    LinearLayout section(String s){LinearLayout l=col();l.setPadding(dp(14),dp(12),dp(14),dp(14));l.setBackground(shape(PANEL,Color.rgb(63,43,112)));TextView h=txt(s,17,Color.WHITE,true);l.addView(h);space(l,6);return l;}
    void addSwitch(LinearLayout p,String label,boolean checked){Switch sw=new Switch(this);sw.setText(label);sw.setTextSize(14);sw.setTextColor(Color.WHITE);sw.setPadding(0,dp(5),0,dp(5));sw.setChecked(checked);sw.setOnCheckedChangeListener((b,on)->Toast.makeText(this,label+(on?": ligado":": desligado"),Toast.LENGTH_SHORT).show());p.addView(sw,new LinearLayout.LayoutParams(-1,-2));}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setBackground(shape(Color.rgb(90,25,190),PURPLE));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(48));lp.topMargin=dp(6);b.setLayoutParams(lp);return b;}
    @Override public void onCreate(Bundle b){super.onCreate(b);showHome();}
    void showHome(){
        ScrollView sc=new ScrollView(this);sc.setBackgroundColor(BG);LinearLayout root=col();root.setPadding(dp(16),dp(18),dp(16),dp(20));sc.addView(root);
        LinearLayout head=col();head.setPadding(dp(16),dp(16),dp(16),dp(16));head.setBackground(shape(PANEL,PURPLE));head.addView(txt("☠  TNT V2.9",27,Color.WHITE,true));head.addView(txt("PAINEL DE CONTROLE • PROTÓTIPO",12,CYAN,true));space(head,8);status=txt("●  PRONTO PARA TESTE",13,Color.rgb(80,255,160),true);head.addView(status);root.addView(head);space(root,14);
        TextView note=txt("Demonstração: estes controles mudam apenas a interface. Não controlam Free Fire nem detectam jogadores reais.",13,Color.LTGRAY,false);root.addView(note);space(root,12);
        LinearLayout aim=section("🎯  AIMBOT (VISUAL)");addSwitch(aim,"Modo de demonstração",false);addSwitch(aim,"Indicador de foco",true);addSwitch(aim,"Suavização visual",true);root.addView(aim);space(root,12);
        LinearLayout esp=section("👁  ESP (VISUALIZAÇÃO)");addSwitch(esp,"Caixas de exemplo",true);addSwitch(esp,"Nomes fictícios",true);addSwitch(esp,"Distâncias fictícias",false);root.addView(esp);space(root,12);
        LinearLayout fs=section("⭕  FOV VISUAL");addSwitch(fs,"Mostrar círculo de FOV",true);TextView fl=txt("Tamanho do FOV: "+fov+"°",15,Color.WHITE,true);fs.addView(fl);SeekBar seek=new SeekBar(this);seek.setMax(170);seek.setProgress(110);seek.setProgressTintList(android.content.res.ColorStateList.valueOf(PURPLE));seek.setThumbTintList(android.content.res.ColorStateList.valueOf(CYAN));fs.addView(seek);seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean u){fov=p+10;fl.setText("Tamanho do FOV: "+fov+"°");}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});root.addView(fs);space(root,12);
        LinearLayout act=section("⚙  AÇÕES");Button test=btn("Testar painel");test.setOnClickListener(v->{status.setText("● TESTE EXECUTADO • FOV "+fov+"°");Toast.makeText(this,"Protótipo funcionando • FOV "+fov+"°",Toast.LENGTH_SHORT).show();});act.addView(test);Button reset=btn("Restaurar padrões");reset.setOnClickListener(v->{showHome();Toast.makeText(this,"Interface reiniciada.",Toast.LENGTH_SHORT).show();});act.addView(reset);root.addView(act);space(root,16);TextView foot=txt("TNT V2.9 • DEMO UI • v1.0",11,Color.GRAY,true);foot.setGravity(Gravity.CENTER);root.addView(foot);setContentView(sc);
    }
}
